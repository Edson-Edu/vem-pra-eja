import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/services.dart'; 
import 'package:geolocator/geolocator.dart'; // Import necessário para GPS
import '../leitor_texto.dart'; 
import 'tela_nivel.dart'; 

class TelaAbertura extends StatefulWidget {
  const TelaAbertura({
    super.key,
  });

  @override
  State<TelaAbertura> createState() => _TelaAberturaState();
}

class _TelaAberturaState extends State<TelaAbertura> {
  bool _mostrarLogo = false;
  // Variável para guardar a localização se ela carregar a tempo
  Position? _posicaoInicialCarregada; 

  @override
  void initState() {
    super.initState();
    
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    
    // CHAMADA MESTRE: Inicia a busca do GPS no SEGUNDO ZERO!
    _preCarregarLocalizacao();
    
    _iniciarSplash();
  }

  // Função para carregar a localização em paralelo à animação
  Future<void> _preCarregarLocalizacao() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return;
      }
      
      // Busca a localização com alta precisão enquanto a animação roda
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      
      if (mounted) {
        setState(() {
          _posicaoInicialCarregada = position;
        });
        debugPrint('GPS Pré-carregado com sucesso!');
      }
    } catch (e) {
      debugPrint('Erro no pré-carregamento do GPS: $e');
    }
  }

  void _iniciarSplash() async {
    // 1. Mostra a logo animada
    Future.delayed(
      const Duration(
        milliseconds: 500,
      ), 
      () {
        if (mounted) {
          setState(() {
            _mostrarLogo = true;
          });
        }
      },
    );

    // 2. Lê a mensagem de boas vindas automaticamente se a voz estiver ligada
    Future.delayed(
      const Duration(
        milliseconds: 600,
      ),
      () async {
        if (acessibilidadeAtivada.value) {
          await configurarTts();
          await gerenciadorVoz.speak(
            "Bem-vindo ao aplicativo Vem pra EJA.",
          );
        }
      }
    );
    
    // 3. Pula sozinho para a tela de Nível após 3.5 segundos
    Future.delayed(
      const Duration(
        milliseconds: 3500,
      ), 
      () {
        if (mounted) {
          pararVoz();
          // MÁGICA: Passa a localização pré-carregada para a próxima tela
          Navigator.pushReplacement(
            context, 
            MaterialPageRoute(
              builder: (context) => TelaNivel(
                posicaoPreCarregada: _posicaoInicialCarregada,
              ),
            ),
          );
        }
      },
    );
  }

  @override
  void dispose() {
    pararVoz(); 
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(
        0xFFFAFAFA, // Novo Off-White Puro
      ),
      body: Container(
        width: double.infinity, 
        height: double.infinity,
        child: Stack( // Usamos Stack para o loader no rodapé
          alignment: Alignment.center,
          children: [
            FadeIn(
              duration: const Duration(
                milliseconds: 1000,
              ),
              animate: _mostrarLogo,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ElasticIn(
                    duration: const Duration(
                      milliseconds: 1500,
                    ),
                    animate: _mostrarLogo,
                    child: Container(
                      padding: const EdgeInsets.all(
                        25,
                      ),
                      decoration: const BoxDecoration(
                        color: Color(0xFF3F51B5), // Novo Índigo Profundo
                        shape: BoxShape.circle, 
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12, 
                            blurRadius: 15, 
                            offset: Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.school_rounded, 
                        size: 70, 
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  FadeInUp(
                    duration: const Duration(
                      milliseconds: 1000,
                    ),
                    animate: _mostrarLogo,
                    child: TextoAcessivel(
                      texto: 'Vem Pra Eja',
                      alinhamento: TextAlign.center,
                      estilo: GoogleFonts.inter( // Nova Fonte Inter
                        fontSize: 42, 
                        fontWeight: FontWeight.w900, 
                        color: const Color(0xFF3F51B5), // Índigo Título
                        letterSpacing: -1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // LOADER PEQUENO NO RODAPÉ
            Positioned(
              bottom: 50,
              child: FadeIn(
                duration: const Duration(milliseconds: 2000),
                animate: _mostrarLogo,
                child: Column(
                  children: [
                    SizedBox(
                      width: 20, // BEM PEQUENO
                      height: 20, // BEM PEQUENO
                      child: CircularProgressIndicator(
                        strokeWidth: 2, // Fino
                        valueColor: AlwaysStoppedAnimation<Color>(
                          const Color(0xFFFF9800), // ÂMBAR (substituiu verde)
                        ),
                      ),
                    ),
                    const SizedBox(height: 10,),
                    Text(
                      "Carregando polo mais próximo...",
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.grey.shade500,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
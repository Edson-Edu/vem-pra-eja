import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animate_do/animate_do.dart';
import 'dart:math'; 
import 'tela_detalhes.dart';
import '../leitor_texto.dart';

class Escola {
  final String nome;
  final String turno;
  final LatLng posicao;
  final List<String> niveisOferecidos; 
  final String descricao;
  final String auxilios;
  double distanciaMetros;

  Escola({
    required this.nome, 
    required this.turno, 
    required this.posicao, 
    required this.niveisOferecidos, 
    required this.descricao,
    required this.auxilios,
    this.distanciaMetros = 0,
  });
}

class TelaHome extends StatefulWidget {
  final String nivelEscolhido; 
  final Position? posicaoInjetada; // MÁGICA: Recebe a localização pré-carregada

  const TelaHome({
    super.key, 
    required this.nivelEscolhido,
    this.posicaoInjetada,
  });

  @override
  State<TelaHome> createState() => _TelaHomeState();
}

class _TelaHomeState extends State<TelaHome> {
  GoogleMapController? _mapController;
  Position? _minhaLocalizacao;
  Escola? _escolaSelecionadaCard;
  final Set<Marker> _marcadores = {};
  List<Escola> escolasFiltradas = [];
  
  static const CameraPosition _posicaoInicial = CameraPosition(
    target: LatLng(
      -26.9922, 
      -48.6340,
    ), 
    zoom: 13.0,
  );

  @override
  void initState() {
    super.initState();
    
    List<Escola> todasEscolas = [
      Escola(
        nome: 'CEM Professor João Inácio', 
        turno: 'Noturno (19h - 22h)', 
        posicao: const LatLng(
          -26.9950, 
          -48.6350,
        ), 
        niveisOferecidos: [
          'Ensino Fundamental', 
          'Ensino Médio',
        ],
        descricao: 'Nesta escola, além de concluir o ensino, você tem a oportunidade de sair com o certificado de Informática Básica integrado.',
        auxilios: 'Janta garantida no local, passe livre estudantil para o transporte e lanche nos intervalos.',
      ),
      Escola(
        nome: 'Escola Maria Eduarda', 
        turno: 'Matutino / Noturno', 
        posicao: const LatLng(
          -26.9800, 
          -48.6400,
        ), 
        niveisOferecidos: [
          'Ensino Médio',
        ],
        descricao: 'Focada no mercado de trabalho da saúde. Aqui você conclui seus estudos e sai com o certificado de Cuidador de Idosos.',
        auxilios: 'Alimentação completa durante o turno e auxílio transporte para moradores de bairros distantes.',
      ),
      Escola(
        nome: 'Escola Camboriú Centro', 
        turno: 'Noturno', 
        posicao: const LatLng(
          -27.0250, 
          -48.6530,
        ), 
        niveisOferecidos: [
          'Ensino Fundamental',
        ],
        descricao: 'Perfeito para quem está começando agora. Foco total em Alfabetização de Jovens e Adultos com turmas de apoio exclusivo.',
        auxilios: 'Janta no refeitório, material didático fornecido gratuitamente e passe de ônibus.',
      ),
    ];
    
    escolasFiltradas = todasEscolas
        .where(
          (e) => e.niveisOferecidos.contains(
            widget.nivelEscolhido,
          ),
        )
        .toList();
        
    // Verifica se já recebemos a localização pronta da Splash Screen
    if (widget.posicaoInjetada != null) {
      _minhaLocalizacao = widget.posicaoInjetada;
      _calcularDistanciasEGerarMarcadores();
    } else {
      _iniciarMapa();
    }
  }

  @override
  void dispose() {
    pararVoz(); 
    super.dispose();
  }

  Future<void> _iniciarMapa() async {
    await _buscarMinhaLocalizacao();
    _gerarMarcadores();
  }

  Future<void> _buscarMinhaLocalizacao() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return;
    }
    
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return;
      }
    }
    
    Position posicaoAtual = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
    
    if (mounted) {
      setState(() {
        _minhaLocalizacao = posicaoAtual;
      });
      _calcularDistanciasEGerarMarcadores();
    }
  }

  void _calcularDistanciasEGerarMarcadores() {
    if (_minhaLocalizacao == null) return;

    if (mounted) {
      setState(() {
        for (var school in escolasFiltradas) {
          school.distanciaMetros = Geolocator.distanceBetween(
            _minhaLocalizacao!.latitude, 
            _minhaLocalizacao!.longitude, 
            school.posicao.latitude, 
            school.posicao.longitude,
          );
        }
        
        escolasFiltradas.sort(
          (a, b) => a.distanciaMetros.compareTo(
            b.distanciaMetros,
          ),
        );
      });
      _gerarMarcadores();
    }
    
    if (escolasFiltradas.isNotEmpty && _mapController != null) {
      Escola escolaMaisProxima = escolasFiltradas.first;
      
      double minLat = min(
        _minhaLocalizacao!.latitude, 
        escolaMaisProxima.posicao.latitude,
      );
      double maxLat = max(
        _minhaLocalizacao!.latitude, 
        escolaMaisProxima.posicao.latitude,
      );
      double minLng = min(
        _minhaLocalizacao!.longitude, 
        escolaMaisProxima.posicao.longitude,
      );
      double maxLng = max(
        _minhaLocalizacao!.longitude, 
        escolaMaisProxima.posicao.longitude,
      );
      
      _mapController?.animateCamera(
        CameraUpdate.newLatLngBounds(
          LatLngBounds(
            southwest: LatLng(
              minLat, 
              minLng,
            ), 
            northeast: LatLng(
              maxLat, 
              maxLng,
            ),
          ), 
          60.0,
        ),
      );
    }
  }

  void _gerarMarcadores() {
    _marcadores.clear();
    for (var school in escolasFiltradas) {
      _marcadores.add(
        Marker(
          markerId: MarkerId(
            school.nome,
          ), 
          position: school.posicao, 
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueOrange, // NOVO: Marcador Âmbar/Laranja (combina com o tema)
          ), 
          onTap: () {
            setState(() {
              _escolaSelecionadaCard = school;
            });
            _focarNaEscola(
              school.posicao,
            );
          },
        ),
      );
    }
    if (mounted) {
      setState(() {});
    }
  }

  void _focarNaEscola(LatLng local) {
    _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: local, 
          zoom: 16.5,
        ),
      ),
    );
  }
  
  String _formatarDistancia(double metros) {
    if (metros < 1000) {
      return '${metros.toInt()} m';
    } else {
      return '${(metros / 1000).toStringAsFixed(1)} km';
    }
  }

  @override
  Widget build(BuildContext context) {
    final escolaAtiva = _escolaSelecionadaCard;
    
    String leituraEscolas = escolasFiltradas.isEmpty 
        ? 'Nenhuma escola encontrada.' 
        : 'Escolas Disponíveis no mapa: ${escolasFiltradas.map((e) => "${e.nome}, turno ${e.turno}").join('. ')}';

    return Scaffold(
      backgroundColor: const Color(
        0xFFFAFAFA, // Novo Fundo
      ),
      appBar: AppBar(
        title: TextoAcessivel(
          texto: 'Vagas para ${widget.nivelEscolhido}', 
          estilo: GoogleFonts.inter( // Nova Fonte Inter
            fontWeight: FontWeight.w900, 
            color: const Color(
              0xFF3F51B5, // Novo Índigo
            ), 
            fontSize: 16,
          ),
        ),
        backgroundColor: const Color(
          0xFFFAFAFA,
        ), 
        elevation: 0, 
        centerTitle: true, 
        iconTheme: const IconThemeData(
          color: Color(
            0xFF3F51B5, // Novo Índigo
          ),
        ),
        actions: [
          BotaoAcessibilidadeGlobal(
            textoLeituraTela: leituraEscolas,
          )
        ],
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: GoogleMap(
              initialCameraPosition: _posicaoInicial, 
              markers: _marcadores, 
              myLocationEnabled: true, 
              myLocationButtonEnabled: true, 
              zoomControlsEnabled: true, 
              padding: const EdgeInsets.only(
                bottom: 240, 
                top: 100,
              ), 
              onMapCreated: (controller) {
                _mapController = controller;
                // Força o mapa a enquadrar o aluno se a posição já estiver injetada
                if (_minhaLocalizacao != null && escolasFiltradas.isNotEmpty) {
                  _calcularDistanciasEGerarMarcadores();
                }
              }, 
              onTap: (_) {
                setState(() {
                  _escolaSelecionadaCard = null;
                });
              },
            ),
          ),
          
          if (escolaAtiva != null)
            Positioned(
              top: 20, 
              left: 20, 
              right: 20,
              child: FadeInDown(
                duration: const Duration(
                  milliseconds: 400,
                ),
                child: GestureDetector(
                  onTap: () {}, 
                  child: Container(
                    padding: const EdgeInsets.all(
                      16,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white, 
                      borderRadius: BorderRadius.circular(
                        20,
                      ), 
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black26, 
                          blurRadius: 15, 
                          offset: Offset(
                            0, 
                            5,
                          ),
                        )
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 60, 
                          height: 60, 
                          decoration: BoxDecoration(
                            color: const Color(
                              0xFFE8EAF6, // Fundo Índigo super claro
                            ), 
                            borderRadius: BorderRadius.circular(
                              15,
                            ),
                          ), 
                          child: const Icon(
                            Icons.school_rounded, 
                            color: Color(
                              0xFF3F51B5, // Novo Índigo
                            ), 
                            size: 30,
                          ),
                        ),
                        const SizedBox(
                          width: 16,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TextoAcessivel(
                                texto: escolaAtiva.nome, 
                                textoOcultoParaLer: '${escolaAtiva.nome}. Clique em Ver Detalhes abaixo.', 
                                estilo: GoogleFonts.inter( // Nova Fonte Inter
                                  fontWeight: FontWeight.w900, 
                                  fontSize: 16, 
                                  color: const Color(
                                    0xFF3F51B5, // Novo Índigo
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              SizedBox(
                                width: double.infinity, 
                                height: 36, 
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(
                                      0xFFFF9800, // NOVO ÂMBAR - ENERGIA E AÇÃO
                                    ), 
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                        10,
                                      ),
                                    ), 
                                    padding: EdgeInsets.zero,
                                  ), 
                                  onPressed: () {
                                    pararVoz(); 
                                    Navigator.push(
                                      context, 
                                      MaterialPageRoute(
                                        builder: (context) => TelaDetalhes(
                                          nomeEscola: escolaAtiva.nome, 
                                          nivel: widget.nivelEscolhido, 
                                          turno: escolaAtiva.turno, 
                                          horario: escolaAtiva.turno.contains('19h') ? '19h às 22h' : 'A combinar', 
                                          descricao: escolaAtiva.descricao, 
                                          auxilios: escolaAtiva.auxilios, 
                                          distancia: _formatarDistancia(
                                            escolaAtiva.distanciaMetros,
                                          ),
                                        ),
                                      ),
                                    );
                                  }, 
                                  child: const TextoAcessivel(
                                    texto: 'Ver Detalhes', 
                                    corIcone: Colors.white, 
                                    estilo: TextStyle(
                                      fontWeight: FontWeight.bold, 
                                      fontSize: 14, 
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.close, 
                            color: Colors.grey,
                          ), 
                          onPressed: () {
                            setState(() {
                              _escolaSelecionadaCard = null;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            
          Positioned(
            bottom: 0, 
            left: 0, 
            right: 0,
            child: SafeArea(
              bottom: true,
              child: FadeInUp(
                duration: const Duration(
                  milliseconds: 800,
                ),
                child: Container(
                  height: 230,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter, 
                      end: Alignment.topCenter, 
                      colors: [
                        Color(
                          0xFFFAFAFA, // Novo Fundo
                        ), 
                        Color(
                          0xFFFAFAFA,
                        ),
                        Colors.white70, 
                        Colors.transparent,
                      ],
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, 
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 20, 
                          bottom: 12,
                        ), 
                        child: TextoAcessivel(
                          texto: escolasFiltradas.isEmpty ? 'Nenhuma escola encontrada' : 'Escolas Disponíveis', 
                          estilo: GoogleFonts.inter( // Nova Fonte Inter
                            fontSize: 20, 
                            fontWeight: FontWeight.w900, 
                            color: const Color(
                              0xFF3F51B5, // Novo Índigo
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 140, 
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal, 
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                          ), 
                          itemCount: escolasFiltradas.length, 
                          itemBuilder: (context, index) {
                            final school = escolasFiltradas[index];
                            final bool ehAMaisProxima = index == 0 && _minhaLocalizacao != null;
                            final bool estaSelecionada = _escolaSelecionadaCard == school;
                            
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8.0, 
                                vertical: 4.0,
                              ),
                              child: InkWell(
                                onTap: () {
                                  _focarNaEscola(
                                    school.posicao,
                                  ); 
                                  setState(() {
                                    _escolaSelecionadaCard = school;
                                  });
                                },
                                child: Container(
                                  width: 280, 
                                  padding: const EdgeInsets.all(
                                    12,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white, 
                                    borderRadius: BorderRadius.circular(
                                      20,
                                    ), 
                                    border: Border.all(
                                      color: estaSelecionada 
                                          ? const Color(
                                              0xFFFF9800, // Borda Âmbar quando selecionada
                                            ) 
                                          : Colors.transparent, 
                                      width: 2.5,
                                    ), 
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Colors.black12, 
                                        blurRadius: 6, 
                                        offset: Offset(
                                          0, 
                                          3,
                                        ),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 60, 
                                        height: 80, 
                                        decoration: BoxDecoration(
                                          color: const Color(
                                            0xFFE8EAF6, // Fundo Índigo Claro
                                          ), 
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ), 
                                        child: const Icon(
                                          Icons.school_rounded, 
                                          color: Color(
                                            0xFF3F51B5, // Novo Índigo
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 12,
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start, 
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            if (ehAMaisProxima) 
                                              Container(
                                                padding: const EdgeInsets.symmetric(
                                                  horizontal: 6, 
                                                  vertical: 2,
                                                ), 
                                                margin: const EdgeInsets.only(
                                                  bottom: 4,
                                                ), 
                                                decoration: BoxDecoration(
                                                  color: const Color(
                                                    0xFFFF9800, // Tag Âmbar
                                                  ), 
                                                  borderRadius: BorderRadius.circular(
                                                    6,
                                                  ),
                                                ), 
                                                child: const Text(
                                                  'MAIS PRÓXIMO', 
                                                  style: TextStyle(
                                                    color: Colors.white, 
                                                    fontSize: 10, 
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                              
                                            TextoAcessivel(
                                              texto: school.nome, 
                                              estilo: GoogleFonts.inter(
                                                fontWeight: FontWeight.w900, 
                                                fontSize: 14, 
                                                color: const Color(
                                                  0xFF3F51B5, // Novo Índigo
                                                ),
                                                letterSpacing: -0.5,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 4,
                                            ),
                                            Row(
                                              children: [
                                                const Icon(
                                                  Icons.schedule_rounded, 
                                                  size: 12, 
                                                  color: Color(
                                                    0xFF757575, // Cinza mais legível
                                                  ),
                                                ), 
                                                const SizedBox(
                                                  width: 4,
                                                ), 
                                                Text(
                                                  school.turno, 
                                                  style: const TextStyle(
                                                    fontSize: 12, 
                                                    color: Color(
                                                      0xFF757575,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 8,
                                            ),
                                            TextoAcessivel(
                                              texto: _minhaLocalizacao != null 
                                                  ? _formatarDistancia(
                                                      school.distanciaMetros,
                                                    ) 
                                                  : 'Calculando...', 
                                              estilo: const TextStyle(
                                                fontSize: 14, 
                                                fontWeight: FontWeight.bold, 
                                                color: Color(
                                                  0xFFFF9800, // Distância em Âmbar
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}